// C++ program to display “Hello World” on the screen by Nisarg c-29. 
#include<iostream>
using namespace std;

int main()
{
	cout << " C++ program to display Hello World on the screen by Nisarg c-29.\n\n";
	cout << "Hello World\n"; // one can also do endl along with \n .endl causes a flushing of the output buffer every time it is called, whereas \n does not. so I will use \n in c
	return 0;
}