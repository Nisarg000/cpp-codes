// C++ program that will ask the user to input integer value and print it by Nisarg c-29.
#include<iostream>
using namespace std;

int main()
{
	int num;
	cout << "C++ program that will ask the user to input integer value and print it by Nisarg c-29." << endl;
	cout << "Enter any integer value\n";
	cin >> num;
	cout << "You inputed:" << num;
	return 0;
}
