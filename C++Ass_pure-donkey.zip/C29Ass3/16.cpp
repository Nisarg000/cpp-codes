/* C++ program that will ask user to input month and display number of days in that particular month. */
#include<iostream>
#include<bits/stdc++.h> //remove this header file if you recieve an error in mac/linux/ubuntu
using namespace std;
int main()
{
  int month;
  cout <<"Enter the number of month e.g. 1 is for January ";
  cin >> month;

  for (int i = 0; i < 1; ++i)
  {
    if (month == 1 )
    {
      cout << "\nYou have entered January\n";
    }
    if (month == 2)
    {
       cout << "\nYou have entered February\n";
    }
    if (month == 3)
    {
       cout << "\nYou have entered March\n";
    }
    if (month == 4)
    {
       cout << "\nYou have entered April\n";
    }
    if (month == 5)
    {
       cout << "\nYou have entered May\n";
    }
    if (month == 6)
    {
       cout << "\nYou have entered June\n";
    }
    if (month == 7)
    {
       cout << "\nYou have entered July\n";
    }
    if (month == 8)
    {
       cout << "\nYou have entered August\n";
    }
    if (month == 9)
    {
       cout << "\nYou have entered September\n";
    }
    if (month == 10)
    {
       cout << "\nYou have entered October\n";
    }
    if (month == 11)
    {
       cout << "\nYou have entered November\n";
    }
    if (month == 12)
    {
       cout << "\nYou have entered December\n";
    }
  }
  for (int i = 0; i < 1; ++i)
  {
    if (month == 1 )
    {
      cout << "\n January has 31 days\n";
    }
    if (month == 2)
    {
       cout << "\n February has 28 days\n";
    }
    if (month == 3)
    {
       cout << "\n March has 31 days\n";
    }
    if (month == 4)
    {
       cout << "\n April has 30 days\n";
    }
    if (month == 5)
    {
       cout << "\n May has 31 days\n";
    }
    if (month == 6)
    {
       cout << "\n June has 30 days\n";
    }
    if (month == 7)
    {
       cout << "\n July has 31 days\n";
    }
    if (month == 8)
    {
       cout << "\n August has 31 days\n";
    }
    if (month == 9)
    {
       cout << "\n September has 30 days\n";
    }
    if (month == 10)
    {
       cout << "\n October has 31 days\n";
    }
    if (month == 11)
    {
       cout << "\n November has 30 days\n";
    }
    if (month == 12)
    {
       cout << "\n December has 31 days\n";
    }
  }

}