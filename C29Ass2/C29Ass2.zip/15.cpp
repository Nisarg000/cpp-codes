//Write a C++ Program to print integer entered by user only if that number is positive. 
#include<iostream>
using namespace std;

int main()
{
	int user_input_1;

	cout << "Please input an number to see if it is positive:" <<endl;
	cin >> user_input_1; // e.g. 15

	if (user_input_1 > 0) // 15 > 0 
	{
		cout << "The number that you have entered is positive: " <<user_input_1 <<endl; 
		/*since the Q only states that print ONLY +ve no. thats why I have not established 
		if no. is -ve or null using else statement  */
	}

	return 0;
}