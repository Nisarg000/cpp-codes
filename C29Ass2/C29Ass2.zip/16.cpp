// Write a C++ Program to check whether integer entered by user is positive or negative (Considering 0 as positive) 
#include<iostream>
using namespace std;

int main()
{
	int user_input_1;

	cout << "Please input an number to see if it is positive or negative:" <<endl;
	cin >> user_input_1; // e.g. 15

	if (user_input_1 > 0) // 15 > 0 
	{
		cout << "The number that you have entered is positive: " <<user_input_1 <<endl; 
	}
	else if (user_input_1 == 0) // 0 == 0
	{
		cout << "The number that you have entered is zero yet according to Q it is positive here: " <<user_input_1 <<endl;
	}
	else // -15 < 0 then the value will be in minus(negative)
		cout << "The number that you have entered is negative: " <<user_input_1 <<endl; 

	return 0;
}