//Write a C++ program to Print All ASCII Value Table
#include <iostream>
using namespace std;

int main()
{
 char c;
 cout << "Enter a character: ";
 cin >> c;
 cout << "ASCII Value of " << c << " is " << int(c);
 return 0;
}