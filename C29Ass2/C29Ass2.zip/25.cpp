// Write a C++ program to Check for Armstrong Number
#include<iostream>
using namespace std;
int main ()
{
	int num,temp,sum=0,temp_num;
	cout << "Input any number: " <<endl;
	cin >> num;

	temp_num=num; //e.g. 153

	for ( ; num > 0; )
	{
		temp=num%10; // 3
		sum=sum+(temp*temp*temp); //0 * 3
		num=num/10; //15.3 so through this it will continue till it becomes 1.53 till 0.153 so till this in the end it will end
	}

	if (temp_num == sum)
	{
		cout << "The number you have entered is an armstrong number!" << endl;
	}
	else
		cout << "The number you have entered is not an armstrong number!" << endl;
	
	return 0;
}