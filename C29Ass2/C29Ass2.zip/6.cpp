// If a and b are two numbers, find out the values of (a-b)2 and a2+b2-2ab. 
#include <iostream>
using namespace std;

int main()
{
    int a,b,temp_1,temp_2;
    cout << "Enter the first value: "<< endl;
    cin >>  a;
    cout << " Enter the second value: "<< endl;
    cin >> b;

    temp_1=( ( a * a) - 2 * ( a * b) + ( b * b) );
    temp_2=
    ( ( a * a ) + ( b * b ) - 2 * ( a * b ) 
    );

    cout << "The output of (a-b)2 is: " << temp_1 << endl;
    cout << "The output of a2+b2-2ab is: " <<temp_2 << endl;

    return 0;
}