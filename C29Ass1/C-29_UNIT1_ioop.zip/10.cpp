// C++ program to demonstrate the use of comments by Nisarg c-29.
#include<iostream>
using namespace std;

int main()
{
	cout << "C++ program to demonstrate the use of comments by Nisarg c-29." <<endl;
	cout << "Use // for single line comments\n";// for example like this
	cout << "Use /* */ for multi line comments\n"; /* For multi line statements use this comment*/
	return 0;
}