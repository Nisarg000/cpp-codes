// C++ program to read string by Nisarg C-29
#include<iostream>
using namespace std;

int main()
{
	char string[100];
	cout << "C++ program to read string by Nisarg C-29\n";
	cout << "Enter the value of string:";
	cin >> string;
	cout <<"\nYou inputted:" <<string <<endl;
	return 0;
}